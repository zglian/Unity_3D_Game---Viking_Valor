Readme
1.Environment
使用unity架構出整個遊戲，可以使用Windows PC進行遊玩
2.How to play my game
按下click開始遊戲，用WASD控制移動方向，空白鍵可以跳躍，SHIFT+W可以奔跑，用滑鼠控制視野，按左鍵進行攻擊
3.MY game
全部功能(bonus除外)都有完成，攻擊敵人可以獲得金幣，若血量歸零則遊戲結束
4.Bonus
[O] Music
[O] A good game structure design
[X] Some special game objects
[O] How good your game is. 隨然沒有到很精緻，但在這麼短的時間裡，我真的已經很認真做了。

5.Feedback
作業的難度過高，需要花大量的時間做，其他課也需要時間，睡覺也需要留一點時間，作業可以簡單一點，或是可以多上一點UNITY的課，像是開學前三週，教基本語法可以跳過
，或是縮短一點，沒有必要上到三週，如果是連基本語法也不會，我想也修不下去這堂課吧。


說明:A good game structure design
我每一個SCRIPT都沒有寫的太長，有確實把功能拆開來，方便其他人閱讀每一個SCRIPT，在SCRIPT裡面也有拆成不同function寫，不重複謝相同的code，
也有善用pubblic gameobject，讓修改過程變得容易，也適時加入navMesh的使用，讓code看起來更簡潔

範例1
敵人走動的SCRIPT
public class PatrollState : StateMachineBehaviour
{
    float timer;
    List<Transform> wayPoints = new List<Transform>();
    NavMeshAgent agent;
    Transform player;
    float chaseRange = 8;
    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        agent = animator.GetComponent<NavMeshAgent>();
        agent.speed = 1.5f;
        timer = 0;
        GameObject go = GameObject.FindGameObjectWithTag("waypoint");
        foreach (Transform t in go.transform)
            wayPoints.Add(t);
        
        Vector3 pos = new Vector3(Random.Range(0,50), 0, Random.Range(0, 50));
        agent.SetDestination(pos);
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if(agent.remainingDistance <= agent.stoppingDistance)
        {

            Vector3 pos = new Vector3(Random.Range(0, 50), 0, Random.Range(0, 50));
            agent.SetDestination(pos);

        }
        timer += Time.deltaTime;      

        float distance = Vector3.Distance(player.position, animator.transform.position);
        if (distance < chaseRange)
        {
            animator.SetBool("isChasing", true);
        }
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        agent.SetDestination(agent.transform.position);
    }
    
}

範例二
viking攻擊時的武器腳本，設定了attack和collect，是藉由sword和敵人碰撞時attack，sword碰到金幣的時候收集。


public class Sword : MonoBehaviour
{    
    public int damgaeAmount = 20;    
    private void OnCollisionStay(Collision collision)
    {
       	attack(collison);
	collect(collison);
    }
    private void OnCollisionEnter(Collision collision)
    {
        attack(collison);
	collect(collison);
    }
    private void attack(Collision collision)
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (collision.transform.tag == "Enemy")
            {
                collision.transform.GetComponent<EnemyController>().TakeDamage(damgaeAmount);
              
            }
        }
    }
    private void collect(Collision collision)
    {
        if (collision.transform.tag == "Coins")
        {
            Destroy(collision.gameObject);
            textScript.totalCoins += 10;
        }
    }

   
}


